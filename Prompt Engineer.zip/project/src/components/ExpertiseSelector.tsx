import React from 'react';
import { Briefcase } from 'lucide-react';

interface ExpertiseSelectorProps {
  value: string;
  onChange: (value: string) => void;
}

export default function ExpertiseSelector({ value, onChange }: ExpertiseSelectorProps) {
  const fields = [
    { id: 'marketing', label: 'Marketing' },
    { id: 'teaching', label: 'Teaching' },
    { id: 'creative', label: 'Creative Writing' },
    { id: 'technical', label: 'Technical Writing' },
  ];

  return (
    <div className="glass-panel rounded-xl p-4">
      <h3 className="text-sm font-semibold flex items-center gap-2 mb-3">
        <Briefcase className="w-4 h-4 text-purple-400" />
        Field of Expertise
      </h3>
      <div className="space-y-2">
        {fields.map((field) => (
          <label
            key={field.id}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <input
              type="radio"
              name="expertise"
              value={field.id}
              checked={value === field.id}
              onChange={(e) => onChange(e.target.value)}
              className="text-purple-500 focus:ring-purple-500"
            />
            <span className="text-sm text-gray-400 group-hover:text-gray-200 transition-colors">
              {field.label}
            </span>
          </label>
        ))}
      </div>
    </div>
  );
}