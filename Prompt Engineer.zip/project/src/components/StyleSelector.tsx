import React from 'react';
import { Palette } from 'lucide-react';

interface StyleSelectorProps {
  value: string;
  onChange: (value: string) => void;
}

export default function StyleSelector({ value, onChange }: StyleSelectorProps) {
  const styles = [
    { id: 'persuasive', label: 'Persuasive' },
    { id: 'informative', label: 'Informative' },
    { id: 'narrative', label: 'Narrative' },
    { id: 'technical', label: 'Technical' },
  ];

  return (
    <div className="glass-panel rounded-xl p-4">
      <h3 className="text-sm font-semibold flex items-center gap-2 mb-3">
        <Palette className="w-4 h-4 text-purple-400" />
        Output Style
      </h3>
      <div className="space-y-2">
        {styles.map((style) => (
          <label
            key={style.id}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <input
              type="radio"
              name="style"
              value={style.id}
              checked={value === style.id}
              onChange={(e) => onChange(e.target.value)}
              className="text-purple-500 focus:ring-purple-500"
            />
            <span className="text-sm text-gray-400 group-hover:text-gray-200 transition-colors">
              {style.label}
            </span>
          </label>
        ))}
      </div>
    </div>
  );
}