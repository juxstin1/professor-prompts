import React from 'react';
import { Send, Loader2 } from 'lucide-react';

interface PromptInputProps {
  value: string;
  onChange: (value: string) => void;
  onGenerate: () => void;
  isGenerating: boolean;
}

export default function PromptInput({ value, onChange, onGenerate, isGenerating }: PromptInputProps) {
  return (
    <div className="space-y-4">
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Enter your prompt idea (up to 1,200 characters)..."
        className="input-field w-full h-40 p-4 text-gray-200 focus:outline-none focus:ring-1 focus:ring-purple-500/30 resize-none text-sm"
        maxLength={1200}
      />
      <div className="flex justify-between items-center text-xs text-gray-500">
        <span>{value.length}/1,200 characters</span>
        <button
          onClick={onGenerate}
          disabled={!value.trim() || isGenerating}
          className="btn-primary flex items-center gap-2 px-4 py-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isGenerating ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Send className="w-4 h-4" />
          )}
          {isGenerating ? 'Generating...' : 'Generate'}
        </button>
      </div>
    </div>
  );
}