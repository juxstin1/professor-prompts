import React from 'react';
import { ClipboardCopy } from 'lucide-react';

interface PromptOutputProps {
  value: string;
}

export default function PromptOutput({ value }: PromptOutputProps) {
  const handleCopy = () => {
    navigator.clipboard.writeText(value);
  };

  return (
    <div className="space-y-4">
      <div className="input-field min-h-[200px] p-4">
        {value ? (
          <p className="whitespace-pre-wrap">{value}</p>
        ) : (
          <p className="text-gray-500 italic">
            Your generated prompt will appear here...
          </p>
        )}
      </div>
      {value && (
        <button
          onClick={handleCopy}
          className="flex items-center gap-2 px-4 py-2 text-sm text-gray-400 hover:text-gray-200 transition-colors"
        >
          <ClipboardCopy className="w-4 h-4" />
          Copy to clipboard
        </button>
      )}
    </div>
  );
}