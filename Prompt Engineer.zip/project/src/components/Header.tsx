import React from 'react';
import { GraduationCap } from 'lucide-react';

export default function Header() {
  return (
    <header className="relative py-16">
      <div className="absolute inset-0 grid-pattern radial-fade"></div>
      
      <div className="relative">
        <div className="flex items-center justify-center gap-4 mb-6">
          <GraduationCap className="w-8 h-8 text-purple-400 opacity-80" />
          <h1 className="text-4xl font-light tracking-tight gradient-text">
            Prompt Professor
          </h1>
        </div>
        <p className="text-sm text-gray-400 max-w-md mx-auto text-center leading-relaxed">
          Transform your ideas into meticulously crafted, contextually rich prompts 
          engineered for optimal AI responses.
        </p>
      </div>
    </header>
  );
}