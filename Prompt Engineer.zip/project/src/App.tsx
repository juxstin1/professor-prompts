import React, { useState } from 'react';
import { Sparkles, BookOpen } from 'lucide-react';
import PromptInput from './components/PromptInput';
import PromptOutput from './components/PromptOutput';
import StyleSelector from './components/StyleSelector';
import ExpertiseSelector from './components/ExpertiseSelector';
import Header from './components/Header';

function App() {
  const [input, setInput] = useState('');
  const [style, setStyle] = useState('persuasive');
  const [expertise, setExpertise] = useState('marketing');
  const [output, setOutput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = async () => {
    setIsGenerating(true);
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    const generated = `You're Allie, a ${expertise} expert specializing in ${style} communication. Your objective is to ${input}. Create a response that demonstrates deep expertise while maintaining visual richness and practical value.`;
    setOutput(generated);
    setIsGenerating(false);
  };

  return (
    <div className="min-h-screen bg-dark">
      <div className="relative">
        <Header />
        
        <main className="max-w-6xl mx-auto px-4 pb-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="glass-panel rounded-xl p-6">
                <h2 className="text-base font-medium flex items-center gap-2 mb-4 text-gray-300">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  Craft Your Prompt
                </h2>
                <PromptInput 
                  value={input} 
                  onChange={setInput} 
                  onGenerate={handleGenerate}
                  isGenerating={isGenerating}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <StyleSelector value={style} onChange={setStyle} />
                <ExpertiseSelector value={expertise} onChange={setExpertise} />
              </div>
            </div>

            <div className="glass-panel rounded-xl p-6">
              <h2 className="text-base font-medium flex items-center gap-2 mb-4 text-gray-300">
                <BookOpen className="w-4 h-4 text-purple-400" />
                Generated Prompt
              </h2>
              <PromptOutput value={output} />
            </div>
          </div>
        </main>

        <footer className="max-w-6xl mx-auto px-4 py-8 text-center text-xs text-gray-500 border-t border-white/5">
          © {new Date().getFullYear()} Prompt Professor. Engineered for precision.
        </footer>
      </div>
    </div>
  );
}

export default App;